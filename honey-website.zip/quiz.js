document.getElementById("quiz-form").addEventListener("submit", function (e) {
  e.preventDefault();
  const answer = document.querySelector("input[name='answer']:checked");
  const result = document.getElementById("result");
  if (!answer) {
    result.textContent = "請選擇一個選項。";
    return;
  }
  if (answer.value === "C") {
    result.textContent = "答對了！紙巾吸收測試是一種常見辨識方法。";
    result.style.color = "green";
  } else {
    result.textContent = "答錯了，請再試試看。";
    result.style.color = "red";
  }
});
